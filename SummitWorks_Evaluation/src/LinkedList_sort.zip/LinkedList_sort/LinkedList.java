package Evaluation;

public class LinkedList {
	int val;
	LinkedList next;
	public LinkedList(){
		
	}
	public LinkedList(int val) {
		this.val = val;
		
	
	}
}
